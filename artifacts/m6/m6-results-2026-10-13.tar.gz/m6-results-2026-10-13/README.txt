M6 raw results archive (written after the M6 commit e447d3cc15389ba84265f510df94dbb8e97fe8a7).
Measured source commit: 450804238ca8786fb45bdce9f70991fc1765d55f (clean worktree, fresh release and release-noinstr builds).
raw/        the 12 result JSON files the M6 document is computed from (sha256 in PROVENANCE_FROM_COMMIT_e447d3cc.txt)
evidence/   configure/build logs, run logs and exit codes, profile logs, scorer probe, smoke tests, analysis output
binaries/   the four binaries that produced them (sha256 in the provenance file); binaries/lpq_benchmark.release-noinstr is build/release-noinstr/bin/lpq_benchmark
models/     the two protocol-C static models and their reports used as inputs
Not included: the two processed graphs (regenerable; sha256 and header checksums are in the provenance file).
Verify:  sha256sum -c ARCHIVE.sha256  (outside)  and compare raw/*.json against the provenance file.
